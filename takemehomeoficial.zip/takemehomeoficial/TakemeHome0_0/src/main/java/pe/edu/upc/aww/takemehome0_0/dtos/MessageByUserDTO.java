package pe.edu.upc.aww.takemehome0_0.dtos;

public class MessageByUserDTO {

    private String name;
    private int quantityMessage;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantityMessage() {
        return quantityMessage;
    }

    public void setQuantityMessage(int quantityMessage) {
        this.quantityMessage = quantityMessage;
    }

}
