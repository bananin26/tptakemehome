package pe.edu.upc.aww.takemehome0_0.dtos;

public class ListPricesGreaterThan1000DTO {
    private String nameProduct;
    private int priceProduct;

    public String getNameProduct() {
        return nameProduct;
    }

    public void setNameProduct(String nameProduct) {
        this.nameProduct = nameProduct;
    }

    public int getPriceProduct() {
        return priceProduct;
    }

    public void setPriceProduct(int priceProduct) {
        this.priceProduct = priceProduct;
    }
}
